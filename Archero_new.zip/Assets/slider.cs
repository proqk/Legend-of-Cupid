﻿internal class slider
{
}