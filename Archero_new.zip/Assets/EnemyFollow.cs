﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//적: 플레이어 방향으로 에너지파를 쏜다
// 플레이어 방향으로
// 쏜다(애니메이션)
public class EnemyFollow : MonoBehaviour
{
    // Start is called before the first frame update
    Animator animator;
    public float maxHp = 1000f; //전체 hp
    public float currentHp = 1000f; //현재 hp
    public float damage = 100f; //몹의 공격력

    public float speed = 3f; //이동속도
    public GameObject target; //플레이어 위치

    void Start()
    {
        animator = GetComponent<Animator>(); //애니메이션 가져오기
    }

    // Update is called once per frame
    void Update()
    {
        //플레이어의 방향으로
        Vector3 dir = target.transform.position - transform.position; //벡터의 차
        dir.Normalize();
        transform.position += dir * speed * Time.deltaTime; //이동한다
    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.name.Contains("Wall"))
        {
            //따라가는 적->벽 충돌: 튕김
            //어떻게 하는 거야
        }
    }
}
