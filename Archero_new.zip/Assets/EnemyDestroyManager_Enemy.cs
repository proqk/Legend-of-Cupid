﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyDestroyManager_Enemy : MonoBehaviour
{
    Rigidbody rigi;
    // Start is called before the first frame update
    void Start()
    {
        rigi = gameObject.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.name.Contains("Bullet_Player")) 
        {
            //적->적 총알 충돌: 통과
            
            rigi.isKinematic = true;
        }
        //적->플레이어 충돌: 플레이어hp-1
        else if (other.gameObject.name.Contains("Player"))
        {
            HPManager hpm = other.gameObject.GetComponent<HPManager>(); //플레이어의 hp가져옴
            hpm.SetHP(hpm.GetHP() - 1); //HP 1감소
            if (hpm.GetHP() == 0) //HP가 0이면 게임오버
            {
                Destroy(other.gameObject); //플레이어 파괴
                //게임오버=GameOverUI를 활성화
                //GameManager.Instance.gameOverUI.SetActive(true);
            }
        }
        rigi.isKinematic = false; //다시 충돌 되게 돌려놓는다
    }
}
