﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDestroyManager : MonoBehaviour
{
    Rigidbody rigi;
    // Start is called before the first frame update
    void Start()
    {
        rigi = gameObject.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.name.Contains("Bullet_Enemy"))
        {
            //플레이어 총알->적의 총알 충돌: 지나감
            rigi.isKinematic = true;
        }
        else if (other.gameObject.name.Contains("Enemy")) //플레이어 총알->적 충돌
        {
            HPManager hpm = other.gameObject.GetComponent<HPManager>(); //적의 피 닳게
            //ScoreManager scm = other.gameObject.GetComponent<ScoreManager>(); //스코어 올라가게

            hpm.SetHP(hpm.GetHP() - 1); //HP 1감소
            if (hpm.GetHP() == 0) //HP가 0이면 적을 파괴함
            {
                ScoreManager.Inst.SetScore(ScoreManager.Inst.GetCurScore() + 1); //적이 파괴되면 스코어 1 증가
                if (ScoreManager.Inst.GetCurScore() == ScoreManager.Inst.GetMaxScore()) //스코어가 max까지 가면 성공
                {
                    //플레이어를 큐피드로

                    //게임성공=GameClearUI를 활성화
                    //GameManager.Instance.gameClearUI.SetActive(true);
                }
                Destroy(other.gameObject); //적 파괴
            }
            Destroy(this.gameObject); //총알 없앰
        }
        rigi.isKinematic = false; //다시 충돌 되게
    }
}
