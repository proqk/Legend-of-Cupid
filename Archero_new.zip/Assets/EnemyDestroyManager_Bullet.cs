﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyDestroyManager_Bullet : MonoBehaviour
{
    Rigidbody rigi;
    // Start is called before the first frame update
    void Start()
    {
        rigi = gameObject.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.name.Contains("Bullet_Player"))
        {
            //적 총알->적 총알 충돌: 통과
            rigi.isKinematic = true;
        }
        else if (other.gameObject.name.Contains("Enemy"))
        {
            //적 총알->적 충돌: 통과
            rigi.isKinematic = true;
        }
        else if (other.gameObject.name.Contains("Player"))
        {
            //적 총알->플레이어 충돌: 플레이어 hp-1 
            HPManager hpm = other.gameObject.GetComponent<HPManager>(); //플레이어 hp가져옴
            hpm.SetHP(hpm.GetHP() - 1); //HP 1감소
            if (hpm.GetHP() == 0) //HP가 0이면 게임오버
            {
                Destroy(other.gameObject); //플레이어 파괴
                //게임오버=GameOverUI를 활성화
                //GameManager.Instance.gameOverUI.SetActive(true);
            }
            Destroy(this.gameObject); //적 총알->플레이어 충돌하면 총알이 없어짐
        }
        rigi.isKinematic = false;
    }
}
