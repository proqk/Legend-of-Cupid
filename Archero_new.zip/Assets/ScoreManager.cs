﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//플레이어가 적을 죽일 때마다 1씩 증가하다가 max까지 차면 게임성공 출력
//현재 점수
//max점수
//UI
public class ScoreManager : MonoBehaviour
{
    public static ScoreManager Inst;
    private void Awake()
    {
        Inst = this;
    }
    //현재 점수
    int curScore = 0;
    //max점수
    int maxScore = 10;
    //UI
    public Slider slider;

    // Start is called before the first frame update
    void Start()
    {
        curScore = 0;
        slider.maxValue = maxScore;
        slider.value = curScore;
    }
    public void SetScore(int value)
    {
        curScore = value;
        slider.value = curScore;
    }

    public int GetCurScore()
    {
        return curScore;
    }

    public int GetMaxScore()
    {
        return maxScore;
    }

    // Update is called once per frame
    void Update()
    {

    }
}
